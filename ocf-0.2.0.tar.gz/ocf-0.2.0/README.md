Ocf
===

OCaml library to read and write configuration files in JSON syntax.

See [https://zoggy.github.io/ocf](https://zoggy.github.io/ocf) for more
information.

### Installation

````
make all install
````
This installs the `ocf` package.


